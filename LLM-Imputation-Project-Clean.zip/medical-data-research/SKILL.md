---
name: medical-data-research
description: |
  医学数据全流程处理与研究论文生成。支持医疗记录数据（EMR/EHR）的清洗、分析、
  AI算法设计和医学核心期刊论文撰写。专门处理中文医疗术语、CSV格式数据、
  缺失数据补全、统计分析和论文材料生成。
  
  使用场景:
  1. 清洗和处理医疗记录CSV数据
  2. 设计医学AI算法流程（生存分析、风险预测、因果推断）
  3. 生成医学核心期刊论文材料（Abstract/Methods/Results/Discussion）
  4. 医学数据缺失模式分析和补全
  5. 与公开医学数据集（MIMIC、SEER等）对比验证
---

# Medical Data Research - 医学数据研究

全流程医学数据处理与研究论文生成工具。

## 使用场景

### 场景1: 医疗数据清洗与探索
用户: "帮我分析这个胰腺癌患者数据，计算缺失率"
→ 加载CSV → 缺失分析 → 生成统计图表

### 场景2: AI算法流程设计
用户: "设计一个预测胰腺癌患者生存期的模型"
→ 特征工程 → 模型选择 → 交叉验证 → 性能评估

### 场景3: 医学论文材料生成
用户: "基于这个数据分析结果写论文的Methods和Results"
→ 方法学描述 → 结果统计 → 图表说明 → 文献对比

### 场景4: 缺失数据补全
用户: "这个数据集缺失严重，用LLM补全一下"
→ 缺失模式分析 → 分层补全策略 → 验证 → 生成报告

## 核心功能

### 1. 数据加载与预处理
```python
# 使用 pandas 加载医疗记录CSV
df = pd.read_csv('patient_data.csv', encoding='utf-8')

# 处理中文医疗术语编码问题
df = handle_chinese_medical_terms(df)
```

**注意事项**:
- 检查CSV编码（通常是 UTF-8 或 GBK）
- 处理中文列名（建议转换为英文或拼音）
- 识别日期格式（常见：YYYY-MM-DD, YYYY/MM/DD）
- 处理多种缺失标记（空值、'NA'、'无'、'未记录'）

### 2. 医学数据特征分析

#### 2.1 缺失模式分析
使用 scripts/missing_analysis.py 进行完整的缺失分析：
- 特征级缺失率统计
- 患者级缺失分布
- 缺失模式热力图
- 模块级缺失对比（人口学/病史/检查/预后）

#### 2.2 数据质量评估
检查项目:
- 数值范围合理性（年龄 0-120，BMI 10-60）
- 时间线逻辑（诊断日期 ≤ 入院日期 ≤ 手术日期）
- 医学逻辑一致性（死亡患者应有生存时间）
- 与文献报道对比（性别比、合并症率）

### 3. AI算法设计流程

#### 3.1 生存分析（Survival Analysis）
适用场景: 预后预测、中位生存期估计

```python
from lifelines import CoxPHFitter, KaplanMeierFitter

# Cox比例风险模型
cph = CoxPHFitter()
cph.fit(df[features], duration_col='survival_days', event_col='is_deceased')

# Kaplan-Meier曲线
kmf = KaplanMeierFitter()
kmf.fit(df['survival_days'], event_observed=df['is_deceased'])
```

**评估指标**: C-index、Log-rank test、Brier score

#### 3.2 分类/预测模型
适用场景: 疾病诊断、并发症预测

推荐模型:
- XGBoost/LightGBM（表格数据首选）
- 逻辑回归（可解释性要求高）
- 深度学习（大规模影像-临床融合）

**医学AI特殊考虑**:
- 类别不平衡（阳性率通常<20%）
- 需要校准（Calibration）
- 可解释性（SHAP值、特征重要性）

#### 3.3 因果推断
适用场景: 治疗效果评估、风险因素分析

方法选择:
- 倾向评分匹配（PSM）
- 逆概率加权（IPW）
- 工具变量（IV）
- 双重差分（DiD，政策评估）

### 4. 医学论文材料生成

#### 4.1 论文结构模板
使用 assets/paper_template.md 作为起点：

```
标题: [疾病] [研究类型] [核心发现]

Abstract结构:
- Background: 疾病负担、研究缺口
- Objective: 研究目的
- Methods: 数据来源、样本量、分析方法
- Results: 主要发现（量化）
- Conclusions: 临床意义

Methods要点:
- 研究设计（回顾性/前瞻性）
- 纳入排除标准
- 统计方法（需具体到软件版本）
- 伦理审批
```

#### 4.2 期刊选择建议
根据研究类型选择目标期刊：
- **临床预测模型**: Journal of Clinical Oncology, Lancet Oncology
- **AI医学**: Nature Medicine, npj Digital Medicine
- **流行病学**: Cancer Epidemiology, International Journal of Cancer
- **专科**: Pancreas, HPB (专科期刊)

### 5. 缺失数据补全策略

#### 5.1 分层补全框架
```
Tier 1 - 规则补全（零成本）:
  - 文本解析（持续时间、日期）
  - 条件推断（is_smoker=0 → daily_smoking=0）
  - 衍生计算（BMI = weight/height²）

Tier 2 - LLM轻量补全（低成本）:
  - 症状关联推断
  - 临床分期推断
  - 家族史细节

Tier 3 - LLM深度推理（高成本）:
  - 合并症风险估计
  - 预后信息补全
```

#### 5.2 验证要求
- 内部一致性检查
- 与病理/影像结果对比
- 文献报道一致性
- 下游任务性能提升

## 脚本工具

### scripts/data_loader.py
标准化医疗数据加载器
- 自动检测编码
- 统一缺失值标记
- 数据类型推断

### scripts/missing_analysis.py
缺失分析完整流程
- 缺失率统计
- 可视化热力图
- 缺失模式聚类

### scripts/survival_analysis.py
生存分析完整流程
- Kaplan-Meier曲线
- Cox回归
- 竞争风险模型

### scripts/paper_generator.py
论文材料生成器
- Abstract生成
- Methods描述
- Results统计段落

## 参考文献

详细参考信息见:
- references/medical_datasets.md - 公开医学数据集汇总
- references/causal_methods.md - 因果推断方法对比
- references/statistical_guidelines.md - 医学统计指南

## 最佳实践

1. **数据隐私**: 确保患者ID已脱敏，符合HIPAA/网络安全法
2. **伦理审批**: 论文投稿前确认有IRB批件
3. **代码可重复**: 保存随机种子，记录软件版本
4. **结果验证**: 关键发现需与临床专家确认合理性
5. **图表规范**: 遵循目标期刊的图表格式要求

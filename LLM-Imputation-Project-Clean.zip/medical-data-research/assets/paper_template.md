# 医学论文模板

## 标题格式
[研究对象] [研究设计] [核心方法] [主要发现]

示例:
- "Development and Validation of a Machine Learning Model for Predicting 
  Survival in Pancreatic Cancer Patients Using Electronic Health Records"
- "分层LLM增强框架用于胰腺癌电子病历缺失数据补全：基于下游预后分析的验证"

## Abstract 模板

### Background
[疾病]是一种[负担描述]，现有的[问题]。准确预测[结局]对[临床意义]。
然而，[数据挑战]。本研究旨在[目标]。

### Methods
这项回顾性研究纳入[样本量]例[患者类型]，来自[数据来源]。
我们开发了[方法]，包括[ tier 1/2/3 ]。
使用[统计/机器学习方法]进行[分析]。
通过[验证方法]评估性能。

### Results
队列平均年龄[XX]岁，[XX]%为男性。[关键发现1]。
[关键发现2，量化结果]。模型在[验证集]上表现[性能指标]。
与[基准/文献]相比[对比结果]。

### Conclusions
[方法]能有效[应用]。该工具可用于[临床意义]，
帮助[目标人群][行动]。

## Methods 模板

### 2.1 Study Design and Population
- 研究设计: 回顾性队列研究
- 时间范围: [开始日期] 至 [结束日期]
- 数据来源: [医院信息系统/EHR数据库]
- 纳入标准: [具体标准]
- 排除标准: [具体标准]
- 伦理审批: [IRB编号]

### 2.2 Variables
**暴露/特征变量**:
- 人口学: 年龄、性别、BMI
- 合并症: [ICD-10编码列表]
- 实验室: [指标列表]

**结局变量**:
- 主要结局: [定义]
- 次要结局: [定义]

### 2.3 Statistical Analysis
- 描述统计: 均值±标准差/中位数(IQR)
- 组间比较: t检验/Mann-Whitney U检验/卡方检验
- 生存分析: Kaplan-Meier, Cox回归
- 机器学习: [模型], [验证策略]
- 软件: Python 3.9, R 4.2, [包列表]

### 2.4 Missing Data Handling
- 缺失模式: [MCAR/MAR/MNAR假设]
- 处理方法: [插补方法/分层补全]
- 敏感性分析: [方法]

## Results 模板

### 3.1 Patient Characteristics
Table 1: [描述基线特征表]

### 3.2 Missing Data Patterns
[缺失分析结果，图表描述]

### 3.3 Model Performance
[性能指标，C-index, AUC等]

### 3.4 Feature Importance
[重要特征，SHAP值/HR]

### 3.5 Validation
[与文献对比，外部验证]

## Discussion 模板

### Principal Findings
[一句话总结主要发现]

### Comparison with Existing Literature
与[文献1]一致/差异...
与[文献2]相比...

### Clinical Implications
[对临床实践的意义]

### Strengths and Limitations
**优势**:
- 大样本量
- 多中心/长期随访
- 方法创新

**局限**:
- 回顾性设计
- 缺失数据
- 外部泛化性

### Future Directions
[未来研究方向]

## 投稿检查清单

- [ ] 格式符合目标期刊要求
- [ ] 图表分辨率≥300 DPI
- [ ] 参考文献格式正确
- [ ] 补充材料完整
- [ ] 数据可用性声明
- [ ] 利益冲突声明
- [ ] 伦理审批号
- [ ] 作者贡献声明

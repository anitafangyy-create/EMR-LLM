#!/usr/bin/env python3
"""
医学数据缺失分析完整流程
生成统计报告和可视化图表
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import LinearSegmentedColormap

def analyze_missing_comprehensive(df, output_dir="./output"):
    """
    全面的缺失分析
    
    Returns:
        dict: 包含统计结果和图表路径
    """
    import os
    os.makedirs(output_dir, exist_ok=True)
    
    results = {}
    
    # 1. 基本统计
    missing_matrix = df.isnull().astype(int)
    missing_rates = missing_matrix.mean().sort_values(ascending=False)
    
    results['total_cells'] = df.size
    results['missing_cells'] = missing_matrix.sum().sum()
    results['missing_rate_overall'] = results['missing_cells'] / results['total_cells']
    results['feature_missing_rates'] = missing_rates.to_dict()
    
    # 2. 患者级缺失
    patient_missing = missing_matrix.sum(axis=1)
    results['patient_missing_mean'] = patient_missing.mean()
    results['patient_missing_median'] = patient_missing.median()
    
    # 3. 生成热力图
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    
    # 热力图1: 整体缺失
    ax1 = axes[0, 0]
    sample_patients = np.random.choice(df.index, min(100, len(df)), replace=False)
    key_features = [c for c in df.columns if missing_rates[c] < 0.9][:20]
    
    cmap = LinearSegmentedColormap.from_list('missing', ['white', '#d62728'])
    im = ax1.imshow(missing_matrix.loc[sample_patients, key_features].T, 
                    aspect='auto', cmap=cmap)
    ax1.set_title('Missing Value Heatmap (Sample Patients)')
    plt.colorbar(im, ax=ax1)
    
    # 保存
    plt.tight_layout()
    heatmap_path = f"{output_dir}/missing_heatmap.png"
    plt.savefig(heatmap_path, dpi=300, bbox_inches='tight')
    results['heatmap_path'] = heatmap_path
    
    # 4. 保存详细报告
    report_path = f"{output_dir}/missing_report.csv"
    missing_df = pd.DataFrame({
        'feature': missing_rates.index,
        'missing_count': missing_matrix.sum(),
        'missing_rate': missing_rates.values
    })
    missing_df.to_csv(report_path, index=False, encoding='utf-8-sig')
    results['report_path'] = report_path
    
    return results

if __name__ == "__main__":
    # 示例
    df = pd.read_csv("data.csv")
    results = analyze_missing_comprehensive(df)
    print(f"整体缺失率: {results['missing_rate_overall']:.2%}")

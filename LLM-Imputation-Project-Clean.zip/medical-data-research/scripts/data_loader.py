#!/usr/bin/env python3
"""
医学数据标准化加载器
处理中文医疗术语、多种缺失标记、编码问题
"""

import pandas as pd
import numpy as np
import chardet

def detect_encoding(file_path):
    """自动检测文件编码"""
    with open(file_path, 'rb') as f:
        result = chardet.detect(f.read(100000))
    return result['encoding']

def load_medical_data(file_path, **kwargs):
    """
    加载医学CSV数据，自动处理编码和缺失值
    
    Args:
        file_path: CSV文件路径
        **kwargs: 传递给pd.read_csv的其他参数
    
    Returns:
        DataFrame: 清洗后的数据
    """
    # 自动检测编码
    encoding = detect_encoding(file_path)
    print(f"检测到编码: {encoding}")
    
    # 加载数据
    df = pd.read_csv(file_path, encoding=encoding, **kwargs)
    print(f"加载完成: {len(df)} 行 × {len(df.columns)} 列")
    
    # 处理中文列名（可选：转换为拼音）
    df = normalize_column_names(df)
    
    # 统一缺失值标记
    df = standardize_missing_values(df)
    
    return df

def normalize_column_names(df):
    """规范化列名"""
    # 保留原始列名映射
    original_cols = df.columns.tolist()
    
    # 清理列名（去除空格、特殊字符）
    df.columns = df.columns.str.strip().str.replace(' ', '_')
    
    return df

def standardize_missing_values(df):
    """统一缺失值标记为标准NaN"""
    missing_markers = [
        '', 'NA', 'N/A', 'na', 'n/a',
        '无', '未知', '未记录', '未填写',
        'None', 'NULL', 'null',
        '0.0_units', '0_units'
    ]
    
    for col in df.columns:
        if df[col].dtype == 'object':
            df[col] = df[col].replace(missing_markers, np.nan)
    
    return df

def parse_medical_duration(text_value):
    """解析医学持续时间文本"""
    import re
    
    if pd.isna(text_value):
        return np.nan
    
    text = str(text_value).strip()
    
    # 匹配 "360.0_years", "4.0_months" 等格式
    match = re.match(r'(\d+\.?\d*)_(years?|months?|days?)', text, re.IGNORECASE)
    if match:
        value = float(match.group(1))
        unit = match.group(2).lower()
        
        converters = {
            'year': 12, 'years': 12,
            'month': 1, 'months': 1,
            'day': 1/30, 'days': 1/30
        }
        return value * converters.get(unit, 1)
    
    return np.nan

if __name__ == "__main__":
    # 示例用法
    df = load_medical_data("patient_data.csv")
    print(df.head())
